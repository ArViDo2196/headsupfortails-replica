const mongoose = require("mongoose");

const ProductSchema = new mongoose.SchemaType({
    title: {
        type: String, required: true, unique:true 
    },
    desc:{
        type:String, required: true, unique: true
    },
    img:{
        type:String, required: true   
    },
    categories:{
        type:Array,   
    },
    price:{
        type:String, required: true   
    },
    
    
},
{timestamps : true }
);
module.exports= mongoose.model("product", ProductSchema);