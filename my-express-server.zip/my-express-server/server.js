const express = require("express");

const mongoose= require("mongoose");

const dotenv = require("dotenv");
dotenv.config();

const bodyParser =require("body-parser");

const session = require("express-session");

const ejs= require("ejs");






//DB connection
mongoose.connect(process.env.MONGO_URL)
.then(()=> console.log("DB connection sucessfull"))
.catch((err)=>console.log(err));


const app = express();
app.use(express.json());
app.set('view engine','ejs');


//bodyparser middleware
//
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))
// parse application/json
app.use(bodyParser.json())


//express-session middleware
app.use(session({
  secret: 'keyboard cat',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: true }
}))


//express-messages middleware
app.use(require('connect-flash')());
app.use(function (req, res, next) {
  res.locals.messages = require('express-messages')(req, res);
  next();
});


const pages = require(__dirname+ "/routes/pages");
app.use('/', pages);







app.listen(3000,function(){
    console.log("server started on port 3000");
});