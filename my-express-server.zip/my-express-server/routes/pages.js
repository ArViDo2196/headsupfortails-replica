const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");


router.get("/html", function(request, response){
    response.render("index")
})


const DproductsSchema= new mongoose.Schema({
    productname:{
        type:String 
    },
    description:{
        type:String
    },
    price:{
        type:String
    }

})
const prod = mongoose.connection.useDb('products');
const productpage= prod.model('productpage',DproductsSchema);

router.get("/dog-products", function(request, response){
    productpage.find({} , function(err, productpage){
        response.render("dog-products", {
            productslist: productpage
        })
    })
    

})

router.get("/cat-products", function(request, response){
    response.render("cat-products")

})

router.get("/", function(req, res){
    res.render("loginpage");
})

router.get("/signup", function(req, res){
    res.render("signup");
})

const UserSchema = {
    username: {
        type: String, required: true, index:true
    },
    email:{
        type:String, required: true 
    },
    password:{
        type:String, required: true   
    }
    
    
}
const user = mongoose.model("user", UserSchema);


router.post("/",(req, res)=>{
    const newuser = new user({
        username: req.body.username,
        email: req.body.email,
        password: req.body.password,
        
    });
    newuser.save();
    res.redirect("/html");
     
})

router.get("/Trackorder", function(request, response){
    response.sendFile(__dirname + "/Trackorder.html")
})

const SignupSchema = {
    fname: {
        type: String, required: true, index:true
    },
    lname:{
        type:String, required: true 
    },
    username: {
        type: String, required: true
    },
    email:{
        type:String, required: true 
    },
    password:{
        type:String, required: true   
    },
    cpass:{
        type:String, required: true   
    }
    
    
}
const signupuser = mongoose.model("signupuser", SignupSchema);
router.get("/signup.html", function(request, response){
    response.sendFile(__dirname + "/signup.html")

}) 
router.post("/signup.html",(req, res)=>{
    const newsuser = new signupuser({
        fname: req.body.fname,
        lname:req.body.lname,
        username: req.body.username,
        email: req.body.email,
        password: req.body.password,
        cpass: req.body.cpass 

        
    });
    newsuser.save();
    res.redirect("/");
     
})
//Exports
module.exports = router;
