const router = require("express").router();
const user = require(__dirname +"/models/user");

router.post("/", async(req, res)=>{
    const newuser = new user({
        username: req.body.username,
        email: req.body.email,
        password: req.body.email,
        
    });
    try{
     const savedUser= await newuser.save();
     console.log(savedUser);
    res.status(201).json(savedUser);

    }
    catch(err){
        res.status(500).json(err);
    }
    
})